﻿/*
 * zsummerX License
 * -----------
 * 
 * zsummerX is licensed under the terms of the MIT license reproduced below.
 * This means that zsummerX is free software and can be used for both academic
 * and commercial purposes at absolutely no cost.
 * 
 * 
 * ===============================================================================
 * 
 * Copyright (C) 2010-2014 YaweiZhang <yawei_zhang@foxmail.com>.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * ===============================================================================
 * 
 * (end of COPYRIGHT)
 */

#include <zsummerX/frame/FrameTcpSession.h>
#include <zsummerX/frame/FrameTcpSessionManager.h>
#include <zsummerX/frame/FrameMessageDispatch.h>

using namespace zsummer::proto4z;




TcpSession::TcpSession()
{
	zsummer::network::g_appEnvironment.addCreatedSessionCount();
	LCI("TcpSession. total TcpSocketImpl object count =[create:" << zsummer::network::g_appEnvironment.getCreatedSocketCount() << ", close:" << zsummer::network::g_appEnvironment.getClosedSocketCount() << "], total TcpSession object count =[create:"
		<< zsummer::network::g_appEnvironment.getCreatedSessionCount() << ", close:" << zsummer::network::g_appEnvironment.getClosedSessionCount()
		<< "]");
}

TcpSession::~TcpSession()
{
	zsummer::network::g_appEnvironment.addClosedSessionCount();
	while (!_sendque.empty())
	{
		delete _sendque.front();
		_sendque.pop();
	}
	while (!_freeCache.empty())
	{
		delete _freeCache.front();
		_freeCache.pop();
	}
	_sockptr.reset();
	LCI("~TcpSession. total TcpSocketImpl object count =[create:" << zsummer::network::g_appEnvironment.getCreatedSocketCount() << ", close:" << zsummer::network::g_appEnvironment.getClosedSocketCount() << "], total TcpSession object count =[create:"
		<< zsummer::network::g_appEnvironment.getCreatedSessionCount() << ", close:" << zsummer::network::g_appEnvironment.getClosedSessionCount()
		<< "]");
}
void TcpSession::cleanSession(bool isCleanAllData, const std::string &rc4TcpEncryption)
{
	_sockptr.reset();
	_sessionID = InvalidSeesionID;
	_acceptID = InvalidAccepterID;
	_pulseTimerID = zsummer::network::InvalidTimerID;

	_recving.bufflen = 0;
	_sending.bufflen = 0;
	_sendingCurIndex = 0;

	_rc4Encrypt = rc4TcpEncryption;
	_rc4StateRead.makeSBox(_rc4Encrypt);
	_rc4StateWrite.makeSBox(_rc4Encrypt);

	_bFirstRecvData = true;
	_bOpenFlashPolicy = false;

	if (isCleanAllData)
	{
		while (!_sendque.empty())
		{
			_freeCache.push(_sendque.front());
			_sendque.pop();
		}
	}
}

bool TcpSession::bindTcpSocketPrt(const TcpSocketPtr &sockptr, AccepterID aID, SessionID sID, const tagAcceptorConfigTraits &traits)
{
	
	cleanSession(true, traits.rc4TcpEncryption);
	_sockptr = sockptr;
	_sessionID = sID;
	_acceptID = aID;
	_protoType = traits.protoType;
	_pulseInterval = traits.pulseInterval;
	_bOpenFlashPolicy = traits.openFlashPolicy;

	if (!doRecv())
	{
		LCW("bindTcpSocketPrt Failed.");
		return false;
	}
	if (traits.pulseInterval > 0)
	{
		_pulseTimerID = TcpSessionManager::getRef().createTimer(traits.pulseInterval, std::bind(&TcpSession::onPulseTimer, shared_from_this()));
	}
	return true;
}

void TcpSession::bindTcpConnectorPtr(const TcpSocketPtr &sockptr, const std::pair<tagConnctorConfigTraits, tagConnctorInfo> & config)
{
	cleanSession(config.first.reconnectCleanAllData, config.first.rc4TcpEncryption);
	_sockptr = sockptr;
	_sessionID = config.second.cID;
	_protoType = config.first.protoType;
	_pulseInterval = config.first.pulseInterval;

	bool connectRet = _sockptr->doConnect(config.first.remoteIP, config.first.remotePort,
		std::bind(&TcpSession::onConnected, shared_from_this(), std::placeholders::_1, config));
	if (!connectRet)
	{
		LCE("DoConnected Failed: traits=" << config.first);
		return ;
	}
	LCI("DoConnected : traits=" << config.first);
	return ;
}




void TcpSession::onConnected(zsummer::network::ErrorCode ec, const std::pair<tagConnctorConfigTraits, tagConnctorInfo> & config)
{
	if (ec)
	{
		LCW("onConnected failed. ec=" << ec 
			<< ",  config=" << config.first);
		_sockptr.reset();
		TcpSessionManager::getRef().onConnect(config.second.cID, false, shared_from_this());
		return;
	}
	LCI("onConnected success.  config=" << config.first);
	
	if (!doRecv())
	{
		onClose();
		return;
	}
	if (_pulseInterval > 0)
	{
		_pulseTimerID = TcpSessionManager::getRef().createTimer(config.first.pulseInterval, std::bind(&TcpSession::onPulseTimer, shared_from_this()));
	}
	
	
	//用户在该回调中发送的第一包会跑到发送堆栈的栈顶.
	TcpSessionManager::getRef().onConnect(_sessionID, true, shared_from_this());
	if (_sending.bufflen == 0 && !_sendque.empty())
	{
		MessagePack *tmp = _sendque.front();
		_sendque.pop();
		doSend(tmp->buff, tmp->bufflen);
		tmp->bufflen = 0;
		_freeCache.push(tmp);
	}
}

bool TcpSession::doRecv()
{
	return _sockptr->doRecv(_recving.buff + _recving.bufflen, SEND_RECV_CHUNK_SIZE - _recving.bufflen, std::bind(&TcpSession::onRecv, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
}

void TcpSession::close()
{
	_sockptr->doClose();
	if (_pulseTimerID != zsummer::network::InvalidTimerID)
	{
		TcpSessionManager::getRef().cancelTimer(_pulseTimerID);
		_pulseTimerID = zsummer::network::InvalidTimerID;
	}
}

void TcpSession::onRecv(zsummer::network::ErrorCode ec, int nRecvedLen)
{
	if (ec)
	{
		LCD("remote socket closed");
		onClose();
		return;
	}
	_recving.bufflen += nRecvedLen;

	// skip encrypt the flash policy data if that open flash policy.
	// skip encrypt when the rc4 encrypt sbox is empty.
	{
		do 
		{
			//process something when recv first data.
			// flash policy process
			const char * flashPolicyRequestString = "<policy-file-request/>"; //string length is 23 byte, contain null-terminator character.
			unsigned int flashPolicyRequestSize = 23;
			if (_bFirstRecvData && _bOpenFlashPolicy && _acceptID != InvalidAccepterID && _recving.bufflen == flashPolicyRequestSize)
			{
				std::string tmp;
				tmp.assign(_recving.buff, flashPolicyRequestSize-1);
				if (tmp.compare(flashPolicyRequestString) == 0)
				{
					_recving.bufflen -= flashPolicyRequestSize;
					memmove(_recving.buff, _recving.buff + flashPolicyRequestSize, _recving.bufflen);

					const char * flashPolicyResponseString = R"---(<cross-domain-policy><allow-access-from domain="*" to-ports="*"/></cross-domain-policy>)---";
					unsigned int flashPolicyResponseSize = (unsigned int)strlen(flashPolicyResponseString)+1;
					doSend(flashPolicyResponseString, flashPolicyResponseSize);
				}
				_bFirstRecvData = false;
			}
			else if (_bFirstRecvData)
			{
				//do other something.

				//do other something end.
				_bFirstRecvData = false;
			}
			
			if (_rc4Encrypt.empty() || _recving.bufflen == 0)
			{
				break;
			}
			
			unsigned int needEncry = nRecvedLen;
			if (_recving.bufflen < (unsigned int)nRecvedLen)
			{
				needEncry = _recving.bufflen;
			}
			_rc4StateRead.encryption((unsigned char*)_recving.buff + _recving.bufflen - needEncry, needEncry);
		} while (0);
		
	}

	//分包
	unsigned int usedIndex = 0;
	do 
	{
		if (_protoType == PT_TCP)
		{
			auto ret = zsummer::proto4z::checkBuffIntegrity<FrameStreamTraits>(_recving.buff + usedIndex, _recving.bufflen - usedIndex, SEND_RECV_CHUNK_SIZE - usedIndex);
			if (ret.first == zsummer::proto4z::IRT_CORRUPTION
				|| (ret.first == zsummer::proto4z::IRT_SHORTAGE && ret.second + _recving.bufflen > SEND_RECV_CHUNK_SIZE))
			{
				LCT("killed socket: checkBuffIntegrity error ");
				_sockptr->doClose();
				onClose();
				return;
			}
			if (ret.first == zsummer::proto4z::IRT_SHORTAGE)
			{
				break;
			}
			try
			{
				bool bOrgReturn  = MessageDispatcher::getRef().dispatchOrgSessionMessage(_sessionID, _recving.buff + usedIndex, ret.second);
				if (!bOrgReturn)
				{
					LCW("Dispatch Message failed. ");
					continue;
				}
				ReadStreamPack rs(_recving.buff + usedIndex, ret.second);
				ProtoID protocolID = 0;
				rs >> protocolID;
				MessageDispatcher::getRef().dispatchSessionMessage(_sessionID, protocolID, rs);
			}
			catch (std::runtime_error e)
			{
				LCW("MessageEntry catch one exception: " << e.what());
				_sockptr->doClose();
				onClose();
				return;
			}
			usedIndex += ret.second;
		}
		else
		{
			std::string body;
			unsigned int usedLen = 0;
			auto ret = zsummer::proto4z::checkHTTPBuffIntegrity(_recving.buff + usedIndex, 
				_recving.bufflen - usedIndex, 
				SEND_RECV_CHUNK_SIZE - usedIndex,
				_httpHadHeader, _httpIsChunked, _httpCommonLine, _httpHeader,
				body, usedLen);
			if (ret == zsummer::proto4z::IRT_CORRUPTION)
			{
				LCT("killed http socket: checkHTTPBuffIntegrity error sID=" << _sessionID);
				_sockptr->doClose();
				onClose();
				return;
			}
			if (ret == zsummer::proto4z::IRT_SHORTAGE)
			{
				break;
			}
			if (!_httpHadHeader)
			{
				_httpHadHeader = true;
			}
			
			MessageDispatcher::getRef().dispatchSessionHTTPMessage(_sessionID, _httpCommonLine, _httpHeader, body);
			usedIndex += usedLen;
		}
		
	} while (true);
	
	
	if (usedIndex > 0)
	{
		_recving.bufflen = _recving.bufflen - usedIndex;
		if (_recving.bufflen > 0)
		{
			memmove(_recving.buff, _recving.buff + usedIndex, _recving.bufflen);
		}
	}
	
	if (!doRecv())
	{
		onClose();
	}
}

void TcpSession::doSend(const char *buf, unsigned int len)
{
	if (!_rc4Encrypt.empty())
	{
		_rc4StateWrite.encryption((unsigned char*)buf, len);
	}
	
	if (_sending.bufflen != 0)
	{
		MessagePack *pack = NULL;
		if (_freeCache.empty())
		{
			pack = new MessagePack();
		}
		else
		{
			pack = _freeCache.front();
			_freeCache.pop();
		}
		
		memcpy(pack->buff, buf, len);
		pack->bufflen = len;
		_sendque.push(pack);
	}
	else
	{
		memcpy(_sending.buff, buf, len);
		_sending.bufflen = len;
		bool sendRet = _sockptr->doSend(_sending.buff, _sending.bufflen, std::bind(&TcpSession::onSend, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
		if (!sendRet)
		{
			LCW("Send Failed");
		}
	}
}


void TcpSession::onSend(zsummer::network::ErrorCode ec, int nSentLen)
{
	if (ec)
	{
		LCD("remote socket closed");
		return ;
	}
	_sendingCurIndex += nSentLen;
	if (_sendingCurIndex < _sending.bufflen)
	{
		bool sendRet = _sockptr->doSend(_sending.buff + _sendingCurIndex, _sending.bufflen - _sendingCurIndex, std::bind(&TcpSession::onSend, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
		if (!sendRet)
		{
			LCW("Send Failed");
			return;
		}
		
	}
	else if (_sendingCurIndex == _sending.bufflen)
	{
		_sendingCurIndex = 0;
		_sending.bufflen = 0;
		if (!_sendque.empty())
		{
			do
			{
				MessagePack *pack = _sendque.front();
				_sendque.pop();
				memcpy(_sending.buff + _sending.bufflen, pack->buff, pack->bufflen);
				_sending.bufflen += pack->bufflen;
				pack->bufflen = 0;
				_freeCache.push(pack);

				if (_sendque.empty())
				{
					break;
				}
				if (SEND_RECV_CHUNK_SIZE - _sending.bufflen < _sendque.front()->bufflen)
				{
					break;
				}
			} while (true);
			
			bool sendRet = _sockptr->doSend(_sending.buff, _sending.bufflen, std::bind(&TcpSession::onSend, shared_from_this(), std::placeholders::_1, std::placeholders::_2));
			if (!sendRet)
			{
				LCW("Send Failed");
				return;
			}
		}
	}
}

void TcpSession::onPulseTimer()
{
	MessageDispatcher::getRef().dispatchOnSessionPulse(_sessionID, _pulseInterval);
	if (_pulseTimerID == zsummer::network::InvalidTimerID || _pulseInterval == 0)
	{
		return;
	}
	_pulseTimerID = TcpSessionManager::getRef().createTimer(_pulseInterval, std::bind(&TcpSession::onPulseTimer, shared_from_this()));
}

void TcpSession::onClose()
{
	LCI("Client Closed!");
	_sockptr.reset();
	if (_pulseTimerID != zsummer::network::InvalidTimerID)
	{
		TcpSessionManager::getRef().cancelTimer(_pulseTimerID);
		_pulseTimerID = zsummer::network::InvalidTimerID;
	}
	
	if (isConnectID(_sessionID))
	{
		TcpSessionManager::getRef().onConnect(_sessionID, false, shared_from_this());
	}
	else
	{
		TcpSessionManager::getRef().onSessionClose(_acceptID, _sessionID);
	}
}

