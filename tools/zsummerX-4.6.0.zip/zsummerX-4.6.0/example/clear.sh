find ./ -name "cmake_install.cmake" -exec rm -r {} \;
find ./ -name "CMakeCache.txt" -exec rm -r {} \;
find ./ -name "CMakeFiles" -exec rm -r {} \;
