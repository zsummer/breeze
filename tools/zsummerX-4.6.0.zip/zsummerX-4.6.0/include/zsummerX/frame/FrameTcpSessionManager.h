/*
 * zsummerX License
 * -----------
 * 
 * zsummerX is licensed under the terms of the MIT license reproduced below.
 * This means that zsummerX is free software and can be used for both academic
 * and commercial purposes at absolutely no cost.
 * 
 * 
 * ===============================================================================
 * 
 * Copyright (C) 2010-2014 YaweiZhang <yawei_zhang@foxmail.com>.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * ===============================================================================
 * 
 * (end of COPYRIGHT)
 */


#ifndef ZSUMMER_TCPSESSION_MANAGER_H_
#define ZSUMMER_TCPSESSION_MANAGER_H_

#include "FrameHeader.h"
class TcpSession;
typedef  std::shared_ptr<TcpSession> CTcpSessionPtr;

class TcpSessionManager
{
private:
	TcpSessionManager();

public://!get the single and global object pointer   
	static TcpSessionManager & getRef();
	inline static TcpSessionManager * getPtr(){ return &getRef(); };
public:
	bool start();
	void stop();
	void run();

public:
	//handle: std::function<void()>
	//switch initiative, in the multi-thread it's switch call thread simultaneously.
	template<class H>
	void post(H &&h){ _summer->post(std::move(h)); }

public:
	template <class H>
	zsummer::network::TimerID createTimer(unsigned int delayms, H &&h){ return _summer->createTimer(delayms, std::move(h)); }
	bool cancelTimer(unsigned long long timerID){ return _summer->cancelTimer(timerID); }

public:
	//! add acceptor under the configure.
	AccepterID addAcceptor(const tagAcceptorConfigTraits &traits);
	AccepterID getAccepterID(SessionID sID);

	//! add connector under the configure.
	SessionID addConnector(const tagConnctorConfigTraits & traits);

public:
	//send original data. can repeat call because it's used send queue in internal implementation.
	void sendOrgSessionData(SessionID sID, const char * orgData, unsigned int orgDataLen);
	//send LCIc data with protocol id 
	void sendSessionData(SessionID sID, ProtoID pID, const char * userData, unsigned int userDataLen);

	//close session socket.
	void kickSession(SessionID sID);



private:
	void safeStop();
	friend class TcpSession;
	// socket(from accept) on close 
	void onSessionClose(AccepterID aID, SessionID sID);
	// socket(from connect) on close 
	void onConnect(SessionID cID, bool bConnected, const CTcpSessionPtr &session);
	void onAcceptNewClient(zsummer::network::ErrorCode ec, const TcpSocketPtr & s, const TcpAcceptPtr & accepter, AccepterID aID);
private:
	ZSummerPtr _summer;
	bool  _running = true;
	unsigned int  _onlineConnectCounts = 0;//counts online connect when zsummerx will exit

	SessionID _lastAcceptID = 0; //accept ID sequence. range  [0 - -1)
	SessionID _lastSessionID = 0;//session ID sequence. range  [0 - __MIDDLE_SEGMENT_VALUE)
	SessionID _lastConnectID = 0;//connect ID sequence. range  [__MIDDLE_SEGMENT_VALUE - -1)

	std::unordered_map<AccepterID, TcpAcceptPtr> _mapAccepterPtr;
	std::unordered_map<SessionID, CTcpSessionPtr> _mapTcpSessionPtr;

	std::unordered_map<SessionID, std::pair<tagConnctorConfigTraits, tagConnctorInfo> > _mapConnectorConfig;
	std::unordered_map<AccepterID, std::pair<tagAcceptorConfigTraits, tagAcceptorInfo> > _mapAccepterConfig;
public:
};

#endif